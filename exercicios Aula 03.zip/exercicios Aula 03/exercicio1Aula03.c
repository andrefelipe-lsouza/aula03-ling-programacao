#include <stdio.h>

int main(){
	int numeros[4];
	int i;
	int soma = 0;
	float media;
		
	printf("Digite quatro numeros:  \n");
	
	for (i = 0; i < 4; i++){
	printf("Numero %d: ",i+1);
	scanf("%d", &numeros[i]);
	soma += numeros[i];
}	 
    media = soma / 4;

    printf("Soma: %d\n", soma);
    printf("Media: %.2f\n", media);
    
	return 0;
}
