#include <stdio.h>

int main(){
	int matriz[2][3];
	int maior;
	int i,j;
	int contador = 0;
	
	//entrada de dados
	printf("Digite os elementos da matriz: \n");
	for (i = 0; i < 2; i++){//limita o numero de linhas  
		for (j = 0; j < 3; j++){//limita o numero de colunas
	printf("Elemento [%d] [%d]: ", i, j);
	scanf("%d", &matriz[i][j]);//pede ao usuario para preencher a matriz
  }
}
	printf("\nMatriz digitada:\n");
	for (i = 0; i < 2; i++){
		for (j = 0; j < 3; j++){
	printf("%d ", matriz[i][j]);//impress�o da matriz digitada pelo usuario
  }
	printf("\n");
}
    for (i = 0; i < 2; i++){
	  for (j = 0; j < 3; j++){
	    if (matriz[i][j] > 5){//se o numero da matriz for maior ent�o
         contador++;
  }
 }
}
    printf("Elementos maiores que 5: %d\n", contador);
    
	return 0;
}
