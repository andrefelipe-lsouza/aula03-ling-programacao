#include <stdio.h>

int main(){
	int matriz[3][3];
	int maior;
	int soma = 0;
	int i;
	int j;
	
	//entrada de dados
	printf("Digite os elementos da matriz: \n");
	for (i = 0; i < 3; i++){//limita o numero de linhas  
		for (j = 0; j < 3; j++){//limita o numero de colunas
	printf("Elemento [%d] [%d]: ", i, j);
	scanf("%d", &matriz[i][j]);//pede ao usuario para preencher a matriz
  }
}
	printf("\nMatriz digitada:\n");
	for (i = 0; i < 3; i++){
		for (j = 0; j < 3; j++){
	printf("%d ", matriz[i][j]);//impress�o da matriz digitada pelo usuario
  }
	printf("\n");
}
    for (i = 0; i < 3; i++){
	  for (j = 0; j < 3; j++){
	  	if(i == j){
	  		soma = soma + matriz [i][j]; //+ matriz [i][j] + matriz [i][j];
		  }
 }
}
	printf("Soma da diagonal principal da matriz: %d\n", soma);
	
	return 0;
}
