#include <stdio.h>

int main(){
	int numeros[5];
	int i;
	
	//entrada de dados
	printf("Digite cinco numeros: \n");
    
	for (i = 0; i < 5; i++){//pede 5 numeros a partir do primeiro vai incrementando at� chegar no limite 5
	printf("Numero %d: ",i+1);
	scanf("%d", &numeros[i]);//pede ao usuario para digitar 5 numeros
}
    //saida de dados
	printf("Numeros maiores que 10: ", numeros[i]);
	for (i = 0; i < 5; i++){
	  if (numeros[i] > 10){ // verifica se algum numero do vetor numeros � maior que 10
	  	printf("%d ", numeros[i]);
	  }
    	
	}
	return 0;
}
